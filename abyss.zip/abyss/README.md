# Abyss

A memory manipulation class for Windows processes using Python. 

## Installation

To install this package, use: pip install abyss
import ctypes
from ctypes import wintypes

# Define necessary constants
PROCESS_ALL_ACCESS = 0x1F0FFF

# Load kernel32.dll
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

# Define the necessary function prototypes
OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
OpenProcess.restype = wintypes.HANDLE

ReadProcessMemory = kernel32.ReadProcessMemory
ReadProcessMemory.argtypes = [wintypes.HANDLE, wintypes.LPCVOID, ctypes.POINTER(ctypes.c_byte), wintypes.SIZE_T, ctypes.POINTER(wintypes.SIZE_T)]
ReadProcessMemory.restype = wintypes.BOOL

WriteProcessMemory = kernel32.WriteProcessMemory
WriteProcessMemory.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.POINTER(ctypes.c_byte), wintypes.SIZE_T, ctypes.POINTER(wintypes.SIZE_T)]
WriteProcessMemory.restype = wintypes.BOOL

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = [wintypes.HANDLE]
CloseHandle.restype = wintypes.BOOL


class abyss:
    def __init__(self, process_name):
        self.process_name = process_name
        self.process_handle = None
        self.process_id = self.get_process_id()

    def get_process_id(self):
        """Get the process ID based on the process name."""
        # Iterate through all processes
        for proc in self._list_processes():
            if proc.szExeFile.decode('utf-8') == self.process_name:
                return proc.th32ProcessID
        return None

    def _list_processes(self):
        """List all processes and their details."""
        # Using snapshot to list processes
        hSnapshot = ctypes.windll.kernel32.CreateToolhelp32Snapshot(0x2, 0)
        process_entry = wintypes.PROCESSENTRY32()
        process_entry.dwSize = ctypes.sizeof(wintypes.PROCESSENTRY32)

        while ctypes.windll.kernel32.Process32Next(hSnapshot, ctypes.byref(process_entry)):
            yield process_entry

        ctypes.windll.kernel32.CloseHandle(hSnapshot)

    def open_process(self):
        """Open a process for memory manipulation."""
        if self.process_id is None:
            raise Exception("Process not found.")
        
        self.process_handle = OpenProcess(PROCESS_ALL_ACCESS, False, self.process_id)
        if not self.process_handle:
            raise Exception("Unable to open process.")

    def read_memory(self, address, size):
        """Read memory from the process."""
        buffer = ctypes.create_string_buffer(size)
        bytes_read = wintypes.SIZE_T()
        success = ReadProcessMemory(self.process_handle, ctypes.c_void_p(address), buffer, size, ctypes.byref(bytes_read))
        if not success:
            raise Exception("ReadProcessMemory failed.")
        return buffer.raw

    def write_memory(self, address, data):
        """Write memory to the process."""
        size = len(data)
        buffer = ctypes.create_string_buffer(data)
        bytes_written = wintypes.SIZE_T()
        success = WriteProcessMemory(self.process_handle, ctypes.c_void_p(address), buffer, size, ctypes.byref(bytes_written))
        if not success:
            raise Exception("WriteProcessMemory failed.")

    def close_process(self):
        """Close the process handle."""
        if self.process_handle:
            CloseHandle(self.process_handle)
            self.process_handle = None
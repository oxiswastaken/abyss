# setup.py

from setuptools import setup, find_packages

setup(
    name='abyss',
    version='0.1',
    description='welcome to abyss of python gamehacking',
    author='does not exist',
    author_email='does not exist',
    packages=find_packages(),
    install_requires=[
        'pypiwin32',
        'psutil',
    ],
)